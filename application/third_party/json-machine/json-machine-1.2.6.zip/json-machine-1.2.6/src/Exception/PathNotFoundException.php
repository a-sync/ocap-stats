<?php

declare(strict_types=1);

namespace JsonMachine\Exception;

class PathNotFoundException extends JsonMachineException
{
}
