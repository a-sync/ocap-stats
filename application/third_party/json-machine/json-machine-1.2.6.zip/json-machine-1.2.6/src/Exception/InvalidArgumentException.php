<?php

declare(strict_types=1);

namespace JsonMachine\Exception;

class InvalidArgumentException extends JsonMachineException
{
}
