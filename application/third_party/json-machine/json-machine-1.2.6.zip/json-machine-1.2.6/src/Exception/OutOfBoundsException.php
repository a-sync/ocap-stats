<?php

declare(strict_types=1);

namespace JsonMachine\Exception;

class OutOfBoundsException extends JsonMachineException
{
}
