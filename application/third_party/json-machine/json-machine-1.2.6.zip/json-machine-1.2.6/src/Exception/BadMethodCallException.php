<?php

declare(strict_types=1);

namespace JsonMachine\Exception;

class BadMethodCallException extends JsonMachineException
{
}
